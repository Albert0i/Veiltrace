<script lang="ts">
  let { clazz = '' } = $props()
</script>

<header class="m-4 {clazz}">
  <h1 class="text-5xl text-redis-hyper text-center mb-2 font-weight-extrabold tracking-widest">Art Deco</h1>
  <p class="text-xl text-center">Find matching artwork to decorate your home.</p>
</header>
