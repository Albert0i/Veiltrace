export type Artwork = {
  id: string
  title: string
  author: string
  url: string
}
