<script lang="ts">
  import Header from '@components/Header.svelte'
  import Main from '@components/Main.svelte'
</script>

<Header />
<Main />
